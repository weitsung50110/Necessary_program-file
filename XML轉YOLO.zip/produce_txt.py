import xml.etree.ElementTree as ET
import pickle
import os
from os import listdir, getcwd
from os.path import join


#file = open('image/2022train.txt', 'w')


path = '2022train.txt'
with open(path, 'w') as f:
    for i in range(2178):
        f.write(str(i)+'\n')
