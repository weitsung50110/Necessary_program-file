import cv2
#-*- coding: UTF-8 -*-
import numpy as np
import urllib.request
from datetime import datetime
import sys
import os
#C317(Ｍ)臺灣大道-河南路
#http://117.56.11.142:7001/media/00-0F-7C-14-BE-E2.mpjpeg?resolution=1080p&auth=cHVibGljOjVkOTRiODgzYTM1NjA6NTEwMzlkOWQyOGViMzQ0NGI3N2M1ZjI1ZjgzNzY1OWM=

#C321台灣大道惠來路口
#http://117.56.11.142:7001/media/58:03:fb:5e:22:29.mpjpeg?resolution=1280p&auth=cHVibGljOjVkOGNkZjYzMzU1YzA6ZjRlZWNiZmMyMTgxYWUwZjMzZjBkYmNhZGU5ZWU2MTE=

#C704市政北七路-惠中路
#http://117.56.11.142:7001/media/00-12-31-62-79-94.mpjpeg?resolution=1280p&auth=cHVibGljOjVkOGJlNDFmYjMzZTg6MmE4MDYwN2M1NTg0MmQzZTJiNmEzNWQ0MTIyNGEyN2I=
 
#C781松竹路/敦富路
#http://117.56.11.142:7001/media/94:e1:ac:f9:6e:d3.mpjpeg?resolution=1280p&auth=cHVibGljOjVkOGJlOGQ4NDkzMTg6MTIzNzYxMzEyM2U2NDBiNjdjM2I5NzE1YTBiYTE0MTU=

#C410五權路－三民、崇德、錦南路
#http://117.56.11.142:7001/media/00-12-31-62-81-1C.mpjpeg?resolution=1280p&auth=cHVibGljOjVkOGJlOWZiNDY1Yjg6YWI1NGI0MmFmYjY2ODMzOGNjYTNkZmM1NmEwOWRmZDU=

#C406五權西路二段-黎明路
#http://117.56.11.142:7001/media/00-0F-7C-13-DA-BF.mpjpeg?resolution=1280p&auth=cHVibGljOjVkOGJlYzg5NjM3Yjg6NGM1OTJiZDIwZDA1NmIyNTJkNWUxY2IxYjAxZjA1Yzg=

#C746敦化路、中平路
#http://117.56.11.142:7001/media/00-0F-FC-50-F8-27.mpjpeg?resolution=1280p&auth=cHVibGljOjVkOGJlNmMyZjUzNjA6MzM2MzgzNThmMTM5OWI2ZTllNTRiM2YzNGUyNTM5MTU=

#C206中清路二段-經貿七路
#http://117.56.11.142:7001/media/00-0F-7C-13-DA-83.mpjpeg?resolution=1280p&auth=cHVibGljOjVkOGJlNGUzYjQwMDg6YzVkY2U5NzkyMmZhMDZkZGNkNGY1YjQxNWJmNDg2NmI=

#C778黎明路/中平路
#http://117.56.11.142:7001/media/58:03:fb:5e:22:1b.mpjpeg?resolution=1280p&auth=cHVibGljOjVkOGJlNTFlMDEwZDA6NDQ2MzNmNDYwMWNkNWE4Yjc5N2Y3ODYzM2FiODgwMWE=

#~~~~~禁行機車~~~~~
#C775環中東路/軍福十六路
#http://117.56.11.141:8601/Interface/Cameras/GetJPEGStream?Camera=C775&Width=1280&Height=720&Quality=50&FPS=5&AuthUser=web

#C213中清路與中清路引道路口
#http://117.56.11.140:8601/Interface/Cameras/GetJPEGStream?Camera=C213&Width=1280&Height=720&Quality=50&FPS=50&AuthUser=web

#C316(Ｍ)臺灣大道光明陸橋
#http://117.56.11.141:8601/Interface/Cameras/GetJPEGStream?Camera=C316&Width=1980&Height=720&Quality=50&FPS=5&AuthUser=web

#stream = urllib.request.urlopen('http://117.56.11.142:7001/media/64:db:8b:46:ad:c1.mpjpeg?resolution=720p&auth=cHVibGljOjViMjljYzdlMGI5MDg6YTZkODNjMWU2ZjMwYjdkZDE2MWE1ZjE2ZDMwOWYwZTc')

#C405=>C417=>C403=>C402
#C405 2: 20211118 071555
#C417 762:20211118 071732


C317 = http://117.56.11.142:7001/media/00-0F-7C-14-BE-E2.mpjpeg?resolution=1080p&auth=cHVibGljOjVkOTRiODgzYTM1NjA6NTEwMzlkOWQyOGViMzQ0NGI3N2M1ZjI1ZjgzNzY1OWM=
C321 = "http://117.56.11.142:7001/media/58:03:fb:5e:22:29.mpjpeg?resolution=1280p&auth=cHVibGljOjVkOGNkZjYzMzU1YzA6ZjRlZWNiZmMyMTgxYWUwZjMzZjBkYmNhZGU5ZWU2MTE="
C704 = "http://117.56.11.142:7001/media/00-12-31-62-79-94.mpjpeg?resolution=1280p&auth=cHVibGljOjVkOTMyMTNjYTJiOTA6ODZlOTBlZDAxYjNhMTIwYWM0YjAzNTFmNTM2ZDc5ZTI="
#1 taichung C405
C405 = "http://117.56.11.141:8601/Interface/Cameras/GetJPEGStream?Camera=C405&Width=1280&Height=720&Quality=60&FPS=20&AuthUser=web"

#2 taichung C417
C417 = "http://117.56.11.142:7001/media/64:db:8b:46:ad:c1.mpjpeg?resolution=720p&auth=cHVibGljOjVkNjRmZjRlNjEwYzA6ZmE5OTY2NGNlZDgxYzZmM2M3YzM5NWY0NGYwNjlkNDg="

#https://168.thb.gov.tw/
#http://e-traffic.taichung.gov.tw/ATIS_TCC/
#need new auth

#3 taichung C403
C403 = "http://117.56.11.140:8601/Interface/Cameras/GetJPEGStream?Camera=C403&Width=1280&Height=720&Quality=60&FPS=20&AuthUser=web"

#4 taichung C402
C402 = "http://117.56.11.140:8601/Interface/Cameras/GetJPEGStream?Camera=C402&Width=1280&Height=720&Quality=60&FPS=20&AuthUser=web"

#5 C720忠明南路－公益路
C720 = "http://117.56.11.140:8601/Interface/Cameras/GetJPEGStream?Camera=C720&Width=1280&Height=720&Quality=60&FPS=20&AuthUser=web"

#6 taichung C719公益路155巷
C719 = "http://117.56.11.141:8601/Interface/Cameras/GetJPEGStream?Camera=C719&Width=1280&Height=720&Quality=60&FPS=20&AuthUser=web" 

#7 C404五權西路二段-環中路(環中路北側)
C404 = "http://117.56.11.141:8601/Interface/Cameras/GetJPEGStream?Camera=C404&Width=1280&Height=720&Quality=60&FPS=20&AuthUser=web"

#8 C420公益路/黎明路口
C420 = "http://117.56.11.142:7001/media/00-0F-7C-16-C9-B0.mpjpeg?resolution=720p&auth=cHVibGljOjVkMTA0NDM1NzA4Yzg6OWU0NDc5MDQxMGUwNGEwNzAyYzcwNTdkMGU3ZTViNTQ"

C213 = "http://117.56.11.140:8601/Interface/Cameras/GetJPEGStream?Camera=C213&Width=1280&Height=720&Quality=50&FPS=50&AuthUser=web"

video_name = sys.argv[1]
print(video_name)

now = datetime.now() # current date and time
date_time = now.strftime("%Y_%m_%d_%H_%M_%S")
print(date_time)
folder_name = video_name+"/"+date_time
os.makedirs(folder_name,exist_ok=True)

if video_name=="16915":
	stream = urllib.request.urlopen(cam16915)
elif video_name=="21056":
	stream = urllib.request.urlopen(cam21056)
elif video_name=="01":
	stream = urllib.request.urlopen(cam01)	
elif video_name=="326":
	stream = urllib.request.urlopen(cam326)
elif video_name=="C402":
	stream = urllib.request.urlopen(C402)
elif video_name=="C405":
	stream = urllib.request.urlopen(C405)
elif video_name=="C417":
	stream = urllib.request.urlopen(C417)
elif video_name=="C403":
	stream = urllib.request.urlopen(C403)
elif video_name=="C404":
	stream = urllib.request.urlopen(C404)
elif video_name=="C720":
	stream = urllib.request.urlopen(C720)
elif video_name=="C719":
	stream = urllib.request.urlopen(C719)
elif video_name=="C321":
	stream = urllib.request.urlopen(C321)
elif video_name=="C704":
	stream = urllib.request.urlopen(C704)
elif video_name=="C213":
	stream = urllib.request.urlopen(C213)
elif video_name=="taipei295":
	stream = urllib.request.urlopen(taipei295)
else:
	stream = urllib.request.urlopen(taipei296)

frame = 0;
total_bytes = b''
while (frame < 1000): #要幾張照片
    total_bytes += stream.read(1024)
    b = total_bytes.find(b'\xff\xd9') # JPEG end
    if not b == -1:
        a = total_bytes.find(b'\xff\xd8') # JPEG start
        jpg = total_bytes[a:b+2] # actual image
        total_bytes= total_bytes[b+2:] # other informations
        print(frame)
        # decode to colored image ( another option is cv2.IMREAD_GRAYSCALE )
        img = cv2.imdecode(np.fromstring(jpg, dtype=np.uint8), cv2.IMREAD_COLOR) 
        #cv2.imshow('Window name',cv2.flip(img, -1)) # display image while receiving data
        #cv2.imshow('Window name',img) # display image while receiving data
        
        now_save = datetime.now() # current date and time
        save_time = now_save.strftime("%Y_%m_%d_%H_%M_%S_%f")
        imagefile = folder_name+"/"+save_time+".jpg"

        #imagefile = folder_name+"/"+str(frame)+".jpg"
        cv2.imwrite(imagefile, img)
	
        if cv2.waitKey(1) ==27: # if user hit esc            
            break
        frame = frame + 1;
#cv2.destroyWindow('Window name')
