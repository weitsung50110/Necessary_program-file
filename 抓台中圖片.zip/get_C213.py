import os

for i in range( 0, 5, 1):
		
	os.system("python recordingTaichung.py C213")
		
	#if ret == 'False':
	#	print (ret)
	continue
